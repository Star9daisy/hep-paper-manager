__app_name__ = "HEP Paper Manager"
__app_version__ = "0.1.0"
