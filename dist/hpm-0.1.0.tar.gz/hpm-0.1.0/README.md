# HEP Paper Manager (HPM)

HPM is a command-line tool that adds High Energy Physics (HEP) papers to a Notion database. It leverages the Inspire engine to source these academic papers, creating a streamlined process for HEP researchers.

## Features
- Fetch HEP papers via the Inspire engine.
- Directly add fetched papers to your Notion database.
- Interactive CLI for easy setup and usage.

## Installation
Under building...

## Usage
> Before using `hpm`, check this [link](https://developers.notion.com/docs/create-a-notion-integration) to create an integration with the Notion API to let `hpm` work with your database.

1. Use `hpm init` to set up HPM:
   ```
   hpm init
   ```
   During initialization, you will be prompted to provide your Notion API key and select a paper template. It also shows the related directories where you can modify the default paper template or add your own templates.
2. Use `hpm add` to fetch and add a paper to your Notion database:
   ```
   hpm add <template> <parameter>
   ```
   `<parameter>` is a comma-separated string like `"param1,param2"` to pass to the get method of the specified engine. For the default Inspire engine, it is the arxiv ID of the paper.

## Example: Add "[1511.05190] Jet image -- deep learning edition" to a Notion database
1. Let's first create a database in Notion:
   ```
   Arxiv ID: Text
   Citations: Number
   Title: Title
   Journal: Select
   Authors: Multi-select
   Abstract: Text
   ```
   ![database](https://imgur.com/L3pJk1h.png)
   Tips: I prefer to add Authors as a Relation property in which way I could foucus professors in my interest. If you like this too, just add the integration to the related professors database. `hpm` will find authors according to the page Title property in related database and fetched names.

2. Then set up `hpm` with `hpm init`:
   ![hpm init](https://imgur.com/282SiHF.png)

3. Before adding our paper to a database, check the default `paper.yml` template and add the database ID to it:
   ![paper.yml](https://imgur.com/nmXWNrB.png)
   Find the database ID in the database URL, "https://www.notion.so/star9daisy/67877176f7064ed982e177aaf70f27cb?v=ffcad911d3d9416bb91657814242fd27&pvs=4". Here, "67877176f7064ed982e177aaf70f27cb" is the database ID.
   
   Once again, remember to create your database like the add your integration to that database!

4. Now we can add the paper to the database:
  ![hpm add](https://imgur.com/ycWCn3Y.png)
  Check the database in Notion. It now should look like this:
  ![database](https://imgur.com/9U2jdSi.png)

## Engines
- `Inspire`: It fetches papers from the [Inspire engine](https://inspirehep.net/). It is the default engine of `hpm`.
  - Parameters: `arxiv_id`
  - Returns: `Paper(title, authors, abstract, journal, citations)`

## Templates
You can modify the properties in the template. Left is the returned value of the engine and right is the property name in the Notion database.
- `paper.yml`
  ```yaml
  engine: Inspire
  database: <database_id>
  properties:
    arxiv_id: Arxiv ID
    citations: Citations
    title: Title
    journal: Journal
    authors: Authors
    abstract: Abstract
  ```