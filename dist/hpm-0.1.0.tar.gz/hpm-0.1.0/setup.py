# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['hpm', 'hpm.engines', 'hpm.notion', 'hpm.notion.objects', 'hpm.plugins']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.28.2,<3.0.0',
 'tabulate>=0.9.0,<0.10.0',
 'typer[all]>=0.7.0,<0.8.0']

entry_points = \
{'console_scripts': ['hpm = hpm.cli:app']}

setup_kwargs = {
    'name': 'hpm',
    'version': '0.1.0',
    'description': '',
    'long_description': "# Issues\n\n[Fixed] issue #1 \nPaper 251018640 is not fetched correctly from Inspire HEP.\n- Authors have no id but uuid. They belongs to Majorana Collaboration.\n- Get collaboration name instead of single author's.\n\npaper 248571843 authors have id but no collaboration.\npaper 251018640 authors have uuid and collaboration.\nuuid<-> collaboration? yes, check with paper 246210416 CMS.\n\n",
    'author': 'Star9daisy',
    'author_email': 'star9daisy@outlook.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
